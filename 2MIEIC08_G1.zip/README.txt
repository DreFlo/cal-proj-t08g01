Instruções de Compilação:
- Criar um projeto de CLion e copiar a pasta 'src' para o diretório do projeto.
- Carregar o ficheiro 'CMakeLists.txt' fornecido usando 'Load CMake Project'
- Definir como 'working directory' a pasta 'src'
- Correr o projeto

Dependências:
- GraphViewerCpp (https://github.com/dmfrodrigues/GraphViewerCpp)
- Grafos (já incluídos e as suas respetivas pastas necessitam de estar na pasta 'src')

